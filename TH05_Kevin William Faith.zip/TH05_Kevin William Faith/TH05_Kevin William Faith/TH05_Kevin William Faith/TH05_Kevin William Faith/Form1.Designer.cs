﻿namespace TH05_Kevin_William_Faith
{
    partial class STORE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProduct = new System.Windows.Forms.Label();
            this.btnAll = new System.Windows.Forms.Button();
            this.btnFilter = new System.Windows.Forms.Button();
            this.cbFilter = new System.Windows.Forms.ComboBox();
            this.lblCategory = new System.Windows.Forms.Label();
            this.dgPro = new System.Windows.Forms.DataGridView();
            this.lblDetails = new System.Windows.Forms.Label();
            this.tbNama = new System.Windows.Forms.Label();
            this.lbCat = new System.Windows.Forms.Label();
            this.lbHarga = new System.Windows.Forms.Label();
            this.lbStock = new System.Windows.Forms.Label();
            this.tbNamPro = new System.Windows.Forms.TextBox();
            this.cbCat = new System.Windows.Forms.ComboBox();
            this.tbHarga = new System.Windows.Forms.TextBox();
            this.tbStock = new System.Windows.Forms.TextBox();
            this.dgCat = new System.Windows.Forms.DataGridView();
            this.lblNamCat = new System.Windows.Forms.Label();
            this.tbNamCat = new System.Windows.Forms.TextBox();
            this.btnAddPro = new System.Windows.Forms.Button();
            this.btnEdPro = new System.Windows.Forms.Button();
            this.btnRePro = new System.Windows.Forms.Button();
            this.btnAddCat = new System.Windows.Forms.Button();
            this.btnReCat = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgPro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgCat)).BeginInit();
            this.SuspendLayout();
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Location = new System.Drawing.Point(32, 26);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(53, 16);
            this.lblProduct.TabIndex = 0;
            this.lblProduct.Text = "Product";
            // 
            // btnAll
            // 
            this.btnAll.Location = new System.Drawing.Point(234, 51);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(44, 23);
            this.btnAll.TabIndex = 1;
            this.btnAll.Text = "All";
            this.btnAll.UseVisualStyleBackColor = true;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // btnFilter
            // 
            this.btnFilter.Location = new System.Drawing.Point(284, 51);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(54, 23);
            this.btnFilter.TabIndex = 2;
            this.btnFilter.Text = "Filter:";
            this.btnFilter.UseVisualStyleBackColor = true;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // cbFilter
            // 
            this.cbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFilter.FormattingEnabled = true;
            this.cbFilter.Location = new System.Drawing.Point(344, 50);
            this.cbFilter.Name = "cbFilter";
            this.cbFilter.Size = new System.Drawing.Size(90, 24);
            this.cbFilter.TabIndex = 3;
            this.cbFilter.SelectedIndexChanged += new System.EventHandler(this.cbFilter_SelectedIndexChanged);
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new System.Drawing.Point(500, 26);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(62, 16);
            this.lblCategory.TabIndex = 4;
            this.lblCategory.Text = "Category";
            // 
            // dgPro
            // 
            this.dgPro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPro.Location = new System.Drawing.Point(35, 82);
            this.dgPro.MultiSelect = false;
            this.dgPro.Name = "dgPro";
            this.dgPro.RowHeadersWidth = 51;
            this.dgPro.RowTemplate.Height = 24;
            this.dgPro.Size = new System.Drawing.Size(399, 222);
            this.dgPro.TabIndex = 5;
            this.dgPro.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPro_CellClick);
            // 
            // lblDetails
            // 
            this.lblDetails.AutoSize = true;
            this.lblDetails.Location = new System.Drawing.Point(36, 329);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(49, 16);
            this.lblDetails.TabIndex = 6;
            this.lblDetails.Text = "Details";
            // 
            // tbNama
            // 
            this.tbNama.AutoSize = true;
            this.tbNama.Location = new System.Drawing.Point(36, 369);
            this.tbNama.Name = "tbNama";
            this.tbNama.Size = new System.Drawing.Size(47, 16);
            this.tbNama.TabIndex = 7;
            this.tbNama.Text = "Nama:";
            // 
            // lbCat
            // 
            this.lbCat.AutoSize = true;
            this.lbCat.Location = new System.Drawing.Point(18, 406);
            this.lbCat.Name = "lbCat";
            this.lbCat.Size = new System.Drawing.Size(65, 16);
            this.lbCat.TabIndex = 8;
            this.lbCat.Text = "Category:";
            // 
            // lbHarga
            // 
            this.lbHarga.AutoSize = true;
            this.lbHarga.Location = new System.Drawing.Point(36, 439);
            this.lbHarga.Name = "lbHarga";
            this.lbHarga.Size = new System.Drawing.Size(48, 16);
            this.lbHarga.TabIndex = 9;
            this.lbHarga.Text = "Harga:";
            // 
            // lbStock
            // 
            this.lbStock.AutoSize = true;
            this.lbStock.Location = new System.Drawing.Point(39, 473);
            this.lbStock.Name = "lbStock";
            this.lbStock.Size = new System.Drawing.Size(44, 16);
            this.lbStock.TabIndex = 10;
            this.lbStock.Text = "Stock:";
            // 
            // tbNamPro
            // 
            this.tbNamPro.Location = new System.Drawing.Point(92, 369);
            this.tbNamPro.Name = "tbNamPro";
            this.tbNamPro.Size = new System.Drawing.Size(329, 22);
            this.tbNamPro.TabIndex = 11;
            // 
            // cbCat
            // 
            this.cbCat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCat.FormattingEnabled = true;
            this.cbCat.Location = new System.Drawing.Point(92, 406);
            this.cbCat.Name = "cbCat";
            this.cbCat.Size = new System.Drawing.Size(136, 24);
            this.cbCat.TabIndex = 12;
            // 
            // tbHarga
            // 
            this.tbHarga.Location = new System.Drawing.Point(90, 439);
            this.tbHarga.Name = "tbHarga";
            this.tbHarga.Size = new System.Drawing.Size(138, 22);
            this.tbHarga.TabIndex = 13;
            this.tbHarga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbHarga_KeyPress);
            // 
            // tbStock
            // 
            this.tbStock.Location = new System.Drawing.Point(92, 470);
            this.tbStock.Name = "tbStock";
            this.tbStock.Size = new System.Drawing.Size(138, 22);
            this.tbStock.TabIndex = 14;
            this.tbStock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbStock_KeyPress);
            // 
            // dgCat
            // 
            this.dgCat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCat.Location = new System.Drawing.Point(503, 82);
            this.dgCat.MultiSelect = false;
            this.dgCat.Name = "dgCat";
            this.dgCat.RowHeadersWidth = 51;
            this.dgCat.RowTemplate.Height = 24;
            this.dgCat.Size = new System.Drawing.Size(268, 222);
            this.dgCat.TabIndex = 15;
            this.dgCat.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgCat_CellClick);
            // 
            // lblNamCat
            // 
            this.lblNamCat.AutoSize = true;
            this.lblNamCat.Location = new System.Drawing.Point(500, 369);
            this.lblNamCat.Name = "lblNamCat";
            this.lblNamCat.Size = new System.Drawing.Size(47, 16);
            this.lblNamCat.TabIndex = 16;
            this.lblNamCat.Text = "Nama:";
            // 
            // tbNamCat
            // 
            this.tbNamCat.Location = new System.Drawing.Point(553, 363);
            this.tbNamCat.Name = "tbNamCat";
            this.tbNamCat.Size = new System.Drawing.Size(138, 22);
            this.tbNamCat.TabIndex = 17;
            // 
            // btnAddPro
            // 
            this.btnAddPro.Location = new System.Drawing.Point(251, 435);
            this.btnAddPro.Name = "btnAddPro";
            this.btnAddPro.Size = new System.Drawing.Size(75, 65);
            this.btnAddPro.TabIndex = 18;
            this.btnAddPro.Text = "Add product";
            this.btnAddPro.UseVisualStyleBackColor = true;
            this.btnAddPro.Click += new System.EventHandler(this.btnAddPro_Click);
            // 
            // btnEdPro
            // 
            this.btnEdPro.Location = new System.Drawing.Point(332, 435);
            this.btnEdPro.Name = "btnEdPro";
            this.btnEdPro.Size = new System.Drawing.Size(77, 65);
            this.btnEdPro.TabIndex = 19;
            this.btnEdPro.Text = "Edit Product";
            this.btnEdPro.UseVisualStyleBackColor = true;
            this.btnEdPro.Click += new System.EventHandler(this.btnEdPro_Click);
            // 
            // btnRePro
            // 
            this.btnRePro.Location = new System.Drawing.Point(415, 435);
            this.btnRePro.Name = "btnRePro";
            this.btnRePro.Size = new System.Drawing.Size(73, 65);
            this.btnRePro.TabIndex = 20;
            this.btnRePro.Text = "Remove Product";
            this.btnRePro.UseVisualStyleBackColor = true;
            this.btnRePro.Click += new System.EventHandler(this.btnRePro_Click);
            // 
            // btnAddCat
            // 
            this.btnAddCat.Location = new System.Drawing.Point(553, 396);
            this.btnAddCat.Name = "btnAddCat";
            this.btnAddCat.Size = new System.Drawing.Size(85, 42);
            this.btnAddCat.TabIndex = 21;
            this.btnAddCat.Text = "Add Category";
            this.btnAddCat.UseVisualStyleBackColor = true;
            this.btnAddCat.Click += new System.EventHandler(this.btnAddCat_Click);
            // 
            // btnReCat
            // 
            this.btnReCat.Location = new System.Drawing.Point(644, 396);
            this.btnReCat.Name = "btnReCat";
            this.btnReCat.Size = new System.Drawing.Size(85, 42);
            this.btnReCat.TabIndex = 22;
            this.btnReCat.Text = "Remove Category";
            this.btnReCat.UseVisualStyleBackColor = true;
            this.btnReCat.Click += new System.EventHandler(this.btnReCat_Click);
            // 
            // STORE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 512);
            this.Controls.Add(this.btnReCat);
            this.Controls.Add(this.btnAddCat);
            this.Controls.Add(this.btnRePro);
            this.Controls.Add(this.btnEdPro);
            this.Controls.Add(this.btnAddPro);
            this.Controls.Add(this.tbNamCat);
            this.Controls.Add(this.lblNamCat);
            this.Controls.Add(this.dgCat);
            this.Controls.Add(this.tbStock);
            this.Controls.Add(this.tbHarga);
            this.Controls.Add(this.cbCat);
            this.Controls.Add(this.tbNamPro);
            this.Controls.Add(this.lbStock);
            this.Controls.Add(this.lbHarga);
            this.Controls.Add(this.lbCat);
            this.Controls.Add(this.tbNama);
            this.Controls.Add(this.lblDetails);
            this.Controls.Add(this.dgPro);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.cbFilter);
            this.Controls.Add(this.btnFilter);
            this.Controls.Add(this.btnAll);
            this.Controls.Add(this.lblProduct);
            this.Name = "STORE";
            this.Text = "STORE";
            this.Load += new System.EventHandler(this.STORE_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgPro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgCat)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Button btnFilter;
        private System.Windows.Forms.ComboBox cbFilter;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.DataGridView dgPro;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.Label tbNama;
        private System.Windows.Forms.Label lbCat;
        private System.Windows.Forms.Label lbHarga;
        private System.Windows.Forms.Label lbStock;
        private System.Windows.Forms.TextBox tbNamPro;
        private System.Windows.Forms.ComboBox cbCat;
        private System.Windows.Forms.TextBox tbHarga;
        private System.Windows.Forms.TextBox tbStock;
        private System.Windows.Forms.DataGridView dgCat;
        private System.Windows.Forms.Label lblNamCat;
        private System.Windows.Forms.TextBox tbNamCat;
        private System.Windows.Forms.Button btnAddPro;
        private System.Windows.Forms.Button btnEdPro;
        private System.Windows.Forms.Button btnRePro;
        private System.Windows.Forms.Button btnAddCat;
        private System.Windows.Forms.Button btnReCat;
    }
}


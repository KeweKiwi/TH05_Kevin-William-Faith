﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace TH05_Kevin_William_Faith
{
    public partial class STORE : Form
    {
        DataTable dtProdukSimpan;
        DataTable dtProdukTampil;
        DataTable dtCategory;
        int selectedIndex = 0;
        int selectedCat = 0;
        public STORE()
        {
            InitializeComponent();
        }

        private void STORE_Load(object sender, EventArgs e)
        {
            
            cbFilter.Enabled = false;
            dtProdukSimpan = new DataTable();
            dtProdukTampil = new DataTable();
            dtCategory = new DataTable();

            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");
            dtProdukSimpan.Rows.Add("J001","Jas Hitam",100000,10,"C1");
            dtProdukSimpan.Rows.Add("T001","T-Shirt Black Pink",70000,20,"C2");
            dtProdukSimpan.Rows.Add("T002","T-Shirt Obsessive",75000,16,"C2");
            dtProdukSimpan.Rows.Add("R001","Rok Mini",82000,26,"C3");
            dtProdukSimpan.Rows.Add("J002","Jeans Biru",90000,15,"C4");
            dtProdukSimpan.Rows.Add("C001","Celana Pendek Coklat",60000,11,"C4");
            dtProdukSimpan.Rows.Add("C002","Cawat Blink-blink",100000,1,"C5");
            dtProdukSimpan.Rows.Add("R002","Rocca Shirt",50000,8,"C2");

            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
            dtCategory.Rows.Add("C1","Jas");
            dtCategory.Rows.Add("C2","T-Shirt");
            dtCategory.Rows.Add("C3","Rok");
            dtCategory.Rows.Add("C4","Celana");
            dtCategory.Rows.Add("C5","Cawat");

            cbCat.DataSource = dtCategory;
            cbCat.DisplayMember = "Nama Category";

            dtProdukTampil = dtProdukSimpan;

            dgPro.DataSource = dtProdukTampil;
            dgCat.DataSource = dtCategory;

        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            cbFilter.Enabled = true;
            cbFilter.DataSource = dtCategory;
            cbFilter.DisplayMember = "Nama Category";    
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(btnFilter.Enabled==true)
            {
                dtProdukTampil = new DataTable();
                //DataRowView index = (DataRowView) cbFilter.SelectedItem;
                //MessageBox.Show(index["Nama Category"].ToString());

                int index = cbFilter.SelectedIndex;
                //MessageBox.Show(dtCategory.Rows[index]["Nama Category"].ToString());
                dtProdukTampil.Columns.Add("ID Product");
                dtProdukTampil.Columns.Add("Nama Product");
                dtProdukTampil.Columns.Add("Harga");
                dtProdukTampil.Columns.Add("Stock");
                dtProdukTampil.Columns.Add("ID Category");
                foreach (DataRow dr in dtProdukSimpan.Rows)
                {
                    if (dr["ID Category"] == dtCategory.Rows[index]["ID Category"].ToString())
                    {
                        dtProdukTampil.Rows.Add(dr["ID Product"], dr["Nama Product"], dr["Harga"], dr["Stock"], dr["ID Category"]);
                    }
                }
                dgPro.DataSource = dtProdukTampil; 
            }
           
        }

        private void btnAll_Click(object sender, EventArgs e)
        {
            cbFilter.Enabled = false;
            dtProdukTampil = dtProdukSimpan;
            dgPro.DataSource = dtProdukTampil;
        }

        private string numbering(char x)
        {
            //int count = 0;
            string idProduct = "";
            foreach(DataRow dr in dtProdukSimpan.Rows)
            {
                if (dr["ID Product"].ToString()[0] == x)
                {
                    //count++;
                    idProduct = dr["ID Product"].ToString();
                }
            }
            string numericPart = idProduct.TrimStart('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
            //count++;
            int newID = int.Parse(numericPart) + 1;
            return x.ToString() + newID.ToString("000");
        }

        private void btnAddPro_Click(object sender, EventArgs e)
        {
            if(tbNamPro.Text == "" || cbCat.SelectedIndex == -1 || tbHarga.Text == "" || tbStock.Text == "")
            {
                MessageBox.Show("Pastikan semua input terisi!");
            }
            else
            {
                string result = numbering(tbNamPro.Text.ToUpper()[0]);
                int index = cbCat.SelectedIndex;
                dtProdukSimpan.Rows.Add(result, tbNamPro.Text, tbHarga.Text, tbStock.Text, dtCategory.Rows[index]["ID Category"]);
                dtProdukTampil = dtProdukSimpan;
                dgPro.DataSource = dtProdukTampil;
            }
        }

        private void tbHarga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnEdPro_Click(object sender, EventArgs e)
        {
            if (tbNamPro.Text == "" || cbCat.SelectedIndex == -1 || tbHarga.Text == "" || tbStock.Text == "")
            {
                MessageBox.Show("Pastikan semua input terisi!");
            }
            else
            {
                if(Convert.ToInt32(tbStock.Text) == 0)
                {
                    dtProdukSimpan.Rows.RemoveAt(selectedIndex);
                }
                else
                {
                    dtProdukSimpan.Rows[selectedIndex]["Nama Product"]=tbNamPro.Text;
                    dtProdukSimpan.Rows[selectedIndex]["Harga"]=tbHarga.Text;
                    dtProdukSimpan.Rows[selectedIndex]["Stock"]=tbStock.Text;
                    dtProdukSimpan.Rows[selectedIndex]["ID Category"] = dtCategory.Rows[cbCat.SelectedIndex]["ID Category"];
                }
                dtProdukTampil = dtProdukSimpan;
                dgPro.DataSource = dtProdukTampil;

                tbNamPro.Text = "";
                tbHarga.Text = "";
                tbStock.Text = "";
                cbCat.SelectedIndex = -1;
            }
        }

        private void btnRePro_Click(object sender, EventArgs e)
        {
            if(dtProdukSimpan.Rows.Count >0)
            {
                if (tbNamPro.Text == "" || cbCat.SelectedIndex == -1 || tbHarga.Text == "" || tbStock.Text == "")
                {
                    MessageBox.Show("Pastikan semua input terisi!");
                }
                else
                {
                    dtProdukSimpan.Rows.RemoveAt(selectedIndex);
                    dtProdukTampil = dtProdukSimpan;
                    dgPro.DataSource = dtProdukTampil;
                }
            }
            else
            {
                MessageBox.Show("Tidak ada barang lagi");
            }
            
        }

        private void dgPro_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = dgPro.Rows[e.RowIndex];
                tbNamPro.Text = selectedRow.Cells["Nama Product"].Value.ToString();
                tbHarga.Text = selectedRow.Cells["Harga"].Value.ToString();
                tbStock.Text = selectedRow.Cells["Stock"].Value.ToString();

                string idCat = selectedRow.Cells["ID Category"].Value.ToString();

               
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (dtCategory.Rows[i]["ID Category"].ToString() == idCat)
                    {
                        cbCat.SelectedIndex = i;
                    }
                }
                selectedIndex = e.RowIndex;
            }
        }

        private void btnAddCat_Click(object sender, EventArgs e)
        {
            if (tbNamCat.Text == "")
            {
                MessageBox.Show("Pastikan Nama Category Terisi!");
            }
            else
            {
                string newIdCat = numberingCat();
                dtCategory.Rows.Add(newIdCat, tbNamCat.Text);
                dgCat.DataSource = dtCategory;
                cbCat.DataSource = dtCategory;
                cbCat.DisplayMember = "Nama Category";
            }
        }

        private string numberingCat()
        {
            string lastId = dtCategory.Rows[dtCategory.Rows.Count - 1]["ID Category"].ToString();
            int highestId = Convert.ToInt32(lastId.Replace("C", ""));
            return "C" + (highestId + 1).ToString();
        }

        private void btnReCat_Click(object sender, EventArgs e)
        {
            if (tbNamCat.Text == "")
            {
                MessageBox.Show("Pastikan ada category terpilih!");
            }
            else
            {
                string catRemove = dtCategory.Rows[selectedCat]["ID Category"].ToString();
                dtCategory.Rows.RemoveAt(selectedCat);
                dgCat.DataSource = dtCategory;
                cbCat.DataSource = dtCategory;
                cbCat.DisplayMember = "Nama Category";

                List<int> removeIdx = new List<int>();
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i]["ID Category"].ToString() == catRemove)
                    {
                        removeIdx.Add(i);
                    }
                }

                foreach (int j in removeIdx)
                {
                    removeItem(catRemove);
                }

                dtProdukTampil = dtProdukSimpan;
                dgPro.DataSource = dtProdukTampil;
            }

        }

        private void dgCat_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = dgCat.Rows[e.RowIndex];
                tbNamCat.Text = selectedRow.Cells["Nama Category"].Value.ToString();
                selectedCat = e.RowIndex;
            }
        }

        private void removeItem(string catRemove)
        {
            List<int> removeIdx = new List<int>();
            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (dtProdukSimpan.Rows[i]["ID Category"].ToString() == catRemove)
                {
                    removeIdx.Add(i);
                    break;
                }
            }
            dtProdukSimpan.Rows.RemoveAt(removeIdx[0]);
        }
    }
}
